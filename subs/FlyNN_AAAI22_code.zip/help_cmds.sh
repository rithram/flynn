#! /bin/bash

python test/eval_hpdep_kfold_small_data.py --help
python test/eval_synthetic_binary_data.py --help
python test/eval_synthetic_data.py --help
python test/knn_baseline.py --help
python test/sbf_baseline.py --help
python test/flynn_hpo.py --help
python test/scaling_nparties.py --help
python test/test_dp_flynn_syn.py --help
python test/test_dp_flynn_real.py --help
